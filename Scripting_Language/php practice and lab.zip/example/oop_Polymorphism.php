<?php

// Parent class
class Shape {
    public function calculateArea() {
        // This method will be overridden in child classes
    }
}

// Child class 1
class Rectangle extends Shape {
    private $length;
    private $width;

    public function __construct($length, $width) {
        $this->length = $length;
        $this->width = $width;
    }

    public function calculateArea() {
        return $this->length * $this->width;
    }
}

// Child class 2
class Circle extends Shape {
    private $radius;

    public function __construct($radius) {
        $this->radius = $radius;
    }

    public function calculateArea() {
        return pi() * $this->radius * $this->radius;
    }
}

// Create objects of different shapes
$rectangle = new Rectangle(5, 10);
$circle = new Circle(7);

// Call the calculateArea() method on each object
echo "Area of rectangle: " . $rectangle->calculateArea() . "<br>";
echo "Area of circle: " . $circle->calculateArea() . "<br>";

?>
