<?php
// Create a new database connection
$servername = "localhost";
$username = "root"; // Default username for localhost
$password = ""; // Default password for localhost
$dbname = "mydatabase";

$conn = new mysqli($servername, $username, $password);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

// Select the database
$conn->select_db($dbname);

// Create the table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Function to sanitize input data
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Initialize variables for form fields
$id = '';
$name = '';
$email = '';
$address = '';
$phone = '';

// Perform insert or update operation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $address = sanitize_input($_POST['address']);
    $phone = sanitize_input($_POST['phone']);

    // Validate input
    $errors = array();
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    if (empty($address)) {
        $errors[] = "Address is required";
    }
    if (empty($phone)) {
        $errors[] = "Phone number is required";
    }

    if (empty($errors)) {
        // Check if the form is for inserting or updating
        if (empty($_POST['id'])) {
            // Insert new record
            $sql = "INSERT INTO users (name, email, address, phone) VALUES ('$name', '$email', '$address', '$phone')";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
                // Clear form fields
                $name = '';
                $email = '';
                $address = '';
                $phone = '';
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            // Update existing record
            $id = $_POST['id'];
            $sql = "UPDATE users SET name='$name', email='$email', address='$address', phone='$phone' WHERE id='$id'";

            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully";
                // Clear form fields
                $id = '';
                $name = '';
                $email = '';
                $address = '';
                $phone = '';
            } else {
                echo "Error updating record: " . $conn->error;
            }
        }
    } else {
        foreach ($errors as $error) {
            echo $error . "<br>";
        }
    }
}

// Perform delete operation
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM users WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Retrieve data from the table
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// Check if edit link is clicked and populate the form fields
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $sql = "SELECT * FROM users WHERE id='$id'";
    $edit_result = $conn->query($sql);

    if ($edit_result->num_rows == 1) {
        $row = $edit_result->fetch_assoc();
        $name = $row['name'];
        $email = $row['email'];
        $address = $row['address'];
        $phone = $row['phone'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Management</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            margin-top: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="email"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 8px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        td a {
            text-decoration: none;
            color: #333;
        }

        td a:hover {
            text-decoration: underline;
        }

        .error {
            color: #ff0000;
            font-size: 14px;
            margin-top: 5px;
        }

        /* Colorful Backgrounds */
        body {
            background-color: #f0f3f8;
        }

        .container {
            background-color: #ffffff;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group button {
            background-color: #f9fafc;
        }

        table {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Management</h2>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" value="<?php echo $name; ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" value="<?php echo $email; ?>" required>
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" name="address" value="<?php echo $address; ?>" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" name="phone" value="<?php echo $phone; ?>" required>
            </div>

            <?php if ($id) { ?>
                <button type="submit" name="update">Update</button>
            <?php } else { ?>
                <button type="submit" name="insert">Insert</button>
            <?php } ?>

            <?php if (!empty($errors)) { ?>
                <div class="error">
                    <?php foreach ($errors as $error) {
                        echo $error . "<br>";
                    } ?>
                </div>
            <?php } ?>
        </form>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['address'] . "</td>";
                    echo "<td>" . $row['phone'] . "</td>";
                    echo "<td><a href='?delete=" . $row['id'] . "'>Delete</a> | <a href='?edit=" . $row['id'] . "'>Edit</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No records found</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>
