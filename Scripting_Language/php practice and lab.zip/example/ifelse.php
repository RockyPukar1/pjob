<?php
// Example variable
$age = 25;

// If statement
if ($age >= 18) {
    echo "You are an adult.";
} else {
    echo "You are not an adult.";
}
?>