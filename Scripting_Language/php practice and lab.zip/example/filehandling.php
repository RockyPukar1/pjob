<?php
$file = "file.txt";

// Check the existence of the file
if (file_exists($file)) {
    // Attempt to rename the file
    if (rename($file, "newfile.txt")) {
        echo "File renamed successfully.";
    } else {
        echo "ERROR: File cannot be renamed.";
    }
} else {
    echo "ERROR: File does not exist.";
}
?>
