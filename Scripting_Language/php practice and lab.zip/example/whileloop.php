<?php
  $i = 1;
  while ($i <= 10) {
    echo $i . "<br>";
    $i++;
  }
?>
