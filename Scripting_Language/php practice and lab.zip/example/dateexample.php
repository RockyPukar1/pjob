<?php
  // Set the default timezone to use
  date_default_timezone_set('UTC');

  // Print the current date and time
  echo "Current date and time: " . date("Y-m-d H:i:s") . "<br>";

  // Print the current year
  echo "Current year: " . date("Y") . "<br>";

  // Print the current month
  echo "Current month: " . date("F") . "<br>";

  // Print the current day
  echo "Current day: " . date("d") . "<br>";

  // Print the current day of the week
  echo "Current day of the week: " . date("l") . "<br>";

  // Print the number of days in the current month
  echo "Days in the current month: " . date("t") . "<br>";

  // Print the current time in the specified format
  echo "Current time: " . date("h:i:s A") . "<br>";
?>
