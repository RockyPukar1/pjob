<?php

class Animal {
    public function makeSound() {
        return "Animal makes a sound";
    }
}

class Cat extends Animal {
    public function makeSound() {
        return " cat makes sound Meow!";
    }
}

class Dog extends Animal {
    public function makeSound() {
        return "Doog makes sound Woof!";
    }
}

// Create objects of different animals
$animal = new Animal();
$cat = new Cat();
$dog = new Dog();

// Call the makeSound() method on each object
echo $animal->makeSound() . "<br>";  // Output: "Animal makes a sound"
echo $cat->makeSound() . "<br>";     // Output: "Meow!"
echo $dog->makeSound() . "<br>";     // Output: "Woof!"

?>
