<?php
require_once('config.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = $_POST['to'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $headers = "From: litigoner@gmail.com\r\n";
    $headers .= "Reply-To: litigoner@gmail.com\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html\r\n";

    if (mail($to, $subject, $message, $headers)) {
        echo "Email sent successfully.";
    } else {
        echo "Failed to send email.";
    }
}

//add config.php as required and also go through config.php file there 
// set email path with code sendmail_path = "C:\xampp\sendmail\sendmail.exe -t" in php.ini file
//make sure you have installed sendmail.exe file 
//in sendmail.ini file add
//smtp_server=smtp.gmail.com
////smtp_port=587
//auth_username=your_email@gmail.com
//auth_password=your_gmail_password


?>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="to">To:</label>
    <input type="email" id="to" name="to" required><br><br>

    <label for="subject">Subject:</label>
    <input type="text" id="subject" name="subject" required><br><br>

    <label for="message">Message:</label><br>
    <textarea id="message" name="message" rows="5" cols="30" required></textarea><br><br>

    <input type="submit" value="Send Email">
</form>
