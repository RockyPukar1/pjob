<?php
$n=7;
  // Iterate over the range of numbers from 1 to 10
  for ($i = 1; $i <= 10; $i++) {
    // Print the current number
    echo $n."x".$i ."=".$i*$n. "<br>";
  }
?>
