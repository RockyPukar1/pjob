<?php
// Configuration
$allowedTypes = array('jpg', 'jpeg', 'png', 'gif'); // Allowed file types
$maxSize = 2 * 1024 * 1024; // Maximum file size in bytes (2MB)
$uploadDir = 'D:/file/'; // Directory to upload files

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if a file was selected
    if (!empty($_FILES['file']['name'])) {
        $fileName = $_FILES['file']['name'];
        $fileSize = $_FILES['file']['size'];
        $fileTmp = $_FILES['file']['tmp_name'];
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // Check if file type is allowed
        if (in_array($fileType, $allowedTypes)) {
            // Check if file size is within the limit
            if ($fileSize <= $maxSize) {
                // Check if file already exists
                if (!file_exists($uploadDir . $fileName)) {
                    // Move the uploaded file to the desired directory
                    if (move_uploaded_file($fileTmp, $uploadDir . $fileName)) {
                        echo "File uploaded successfully!";
                    } else {
                        echo "File upload failed.";
                    }
                } else {
                    echo "File already exists.";
                }
            } else {
                echo "File size exceeds the limit.";
            }
        } else {
            echo "Invalid file type.";
        }
    } else {
        echo "No file selected.";
    }
}
?>

<form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <input type="submit" value="Upload File">
</form>
