<?php
// Configuration for email settings
$smtpServer = 'smtp.gmail.com';
$smtpPort = 587;
$smtpUsername = 'your_email@gmail.com';
$smtpPassword = 'your_gmail_password';

// Email configuration
$emailFrom = 'litigoner@gmail.com'; // The email address you want to send from
$emailReplyTo = 'litigoner@gmail.com'; // The email address recipients can reply to
$emailHeaders = "From: $emailFrom\r\n";
$emailHeaders .= "Reply-To: $emailReplyTo\r\n";
$emailHeaders .= "MIME-Version: 1.0\r\n";
$emailHeaders .= "Content-type: text/html\r\n";
?>