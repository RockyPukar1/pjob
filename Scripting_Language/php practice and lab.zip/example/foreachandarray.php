<?php
// Define
$contacts = array(
    array(
        "name" => "Krishna Acharya",
        "email" => "krishnaxt@mail.com"
    ),
    array(
        "name" => "Clark Kent",
        "email" => "clarkkent@mail.com"
    ),
    array(
        "name" => "Harry Potter",
        "email" => "harrypotter@mail.com"
    )
);

// Access nested value
for($i=0;$i<3;$i++){
echo " Email-ids : " . $contacts[$i]["email"]."<br>";
}
?>
