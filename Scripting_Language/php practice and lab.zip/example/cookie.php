<?php
// Setting a cookie
setcookie('username', 'John Doe', time() + (30 * 24 * 60 * 60), '/');

// Retrieving the cookie value
if (isset($_COOKIE['username'])) {
    $username = $_COOKIE['username'];
    echo "Welcome back, $username!";
} else {
    echo "Welcome, guest!";
}

// Modifying the cookie
setcookie('username', 'Ram Bahadur', time() + (30 * 24 * 60 * 60), '/');

// Retrieving the modified cookie value
if (isset($_COOKIE['username'])) {
    $username = $_COOKIE['username'];
    echo "<br>Your new username is $username!";
}

// Deleting the cookie
/*setcookie('username', '', time() - 3600, '/');

// Checking if the cookie is deleted
//if (!isset($_COOKIE['username'])) {
    //echo "<br>The username cookie has been deleted.";
}*/
?>
