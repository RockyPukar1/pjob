<?php
$dayOfWeek = date("l");

switch ($dayOfWeek) {
  case "Monday":
    echo "It's Monday, time to start the week off strong!";
    break;
  case "Tuesday":
    echo "It's Tuesday, keep up the momentum!";
    break;
  case "Wednesday":
    echo "It's Wednesday, you're halfway there!";
    break;
  case "Thursday":
    echo "It's Thursday, almost to the weekend!";
    break;
  case "Friday":
    echo "It's Friday, time to celebrate the end of the week!";
    break;
  case "Saturday":
    echo "It's Saturday, enjoy the weekend!";
    break;
  case "Sunday":
    echo "It's Sunday, time to relax and recharge!";
    break;
  default:
    echo "Error: Could not determine day of the week.";
}
?>
