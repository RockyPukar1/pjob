<?php

class MyClass {
    public function __construct() {
        echo "Constructor called!"."<br>";
    }

    public function someMethod() {
        echo "Some method called!\n";
    }

    public function __destruct() {
        echo "Destructor called!\n";
    }
}

// Create an instance of MyClass
$obj = new MyClass();

// Call a method on the object
$obj->someMethod();

// The object will be destroyed automatically at the end of the script

?>
