<!DOCTYPE html>
<html>
<head>
	<title>Grade Calculator</title>
</head>
<body>
	<h1>Grade Calculator</h1>
	<form method="post">
		<label for="marks">Enter your marks:</label>
		<input type="text" id="marks" name="marks">
		<button type="submit">Calculate</button>
	</form>
	<?php
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		// Get the marks from the form submission
		$marks = $_POST['marks'];

		// Calculate the grade
		if ($marks >= 90) {
		    $grade = "A";
		} elseif ($marks >= 80) {
		    $grade = "B";
		} elseif ($marks >= 70) {
		    $grade = "C";
		} elseif ($marks >= 60) {
		    $grade = "D";
		} else {
		    $grade = "F";
		}

		// Output the grade
		echo "<p>Your grade is: " . $grade . "</p>";
	}
	?>
</body>
</html>
