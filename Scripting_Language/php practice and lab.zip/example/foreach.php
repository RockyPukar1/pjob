<?php
$superhero = array(
    "name" => "Ram Bahadur",
    "email" => "rambahadur@gmail.com",
    "age" => "45"
);
foreach ($superhero as $key => $value) {
    echo $key . ": " . $value . "<br>";
}
?>
