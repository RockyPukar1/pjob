<?php
class Car {
    private $brand;
    private $model;
    private $color;

    public function __construct($brand, $model, $color) {
        $this->brand = $brand;
        $this->model = $model;
        $this->color = $color;
    }

    public function getBrand() {
        return $this->brand;
    }

    public function getModel() {
        return $this->model;
    }

    public function getColor() {
        return $this->color;
    }

    public function startEngine() {
        echo "The {$this->brand} {$this->model} is starting the engine.";
    }
}

// Creating an instance of the Car class
$myCar = new Car("Toyota", "Camry", "Blue");

// Accessing properties and methods of the object
echo "Brand: " . $myCar->getBrand() . "<br>";
echo "Model: " . $myCar->getModel() . "<br>";
echo "Color: " . $myCar->getColor() . "<br>";

$myCar->startEngine();
?>
